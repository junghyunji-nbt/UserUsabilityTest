package com.cashslide.userusability2

import android.os.Bundle
import android.support.v7.app.AppCompatActivity
import android.view.View
import kotlinx.android.synthetic.main.activity_detail.*

class DetailActivity : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_detail)

        var intent = intent
        if (intent.extras.getInt("detail") == 0) {
            detail.visibility = View.VISIBLE
        } else {
            detail_video.visibility = View.VISIBLE
        }

    }
}