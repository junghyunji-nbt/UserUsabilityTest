package com.cashslide.userusability2.adapter

import android.content.Context
import android.content.Intent
import android.support.v7.widget.RecyclerView
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import com.bumptech.glide.Glide
import com.bumptech.glide.load.engine.DiskCacheStrategy
import com.cashslide.userusability2.R
import kotlinx.android.synthetic.main.dabang_item.view.*
import kotlinx.android.synthetic.main.list_item.view.*
import kotlinx.android.synthetic.main.lotte_item.view.*
import android.view.animation.AlphaAnimation

import com.cashslide.userusability2.DetailActivity
import kotlinx.android.synthetic.main.yanolza_item.view.*


class CommonAdapter(val context: Context) : RecyclerView.Adapter<RecyclerView.ViewHolder>() {

    companion object {
        val LOTTE_VIEW = 0
        val DABANG_VIEW = 1
        val AD_VIEW = 2
        val YA_VIEW = 3
        val LOTTE_POPUP_VIEW = 0
        val DABANG_POPUP_VIEW = 1
    }

    val imageList = intArrayOf(R.drawable.dummy_1, R.drawable.dummy_2, R.drawable.dummy_3,
            R.drawable.dummy_4, R.drawable.dummy_5, R.drawable.dummy_6, R.drawable.dummy_7,
            R.drawable.dummy_8, R.drawable.dummy_9, R.drawable.dummy_10)

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): RecyclerView.ViewHolder {
        when (viewType) {
            LOTTE_VIEW -> {
                val view = LayoutInflater.from(context).inflate(R.layout.lotte_item, parent, false)
                return LotteViewHolder(view)
            }
            DABANG_VIEW -> {
                val view = LayoutInflater.from(context).inflate(R.layout.dabang_item, parent, false)
                return DabangViewHolder(view)
            }
            AD_VIEW -> {
                val view = LayoutInflater.from(context).inflate(R.layout.list_item, parent, false)
                return CommonViewHolder(view)
            }

            YA_VIEW -> {
                val view = LayoutInflater.from(context).inflate(R.layout.yanolza_item, parent, false)
                return YaViewHolder(view)
            }
            LOTTE_POPUP_VIEW-> {
                val view = LayoutInflater.from(context).inflate(R.layout.lotte_popup_item, parent, false)
                return PopupViewHolder(view)
            }
            DABANG_POPUP_VIEW -> {
                val view = LayoutInflater.from(context).inflate(R.layout.dabang_popup_item, parent, false)
                return PopupViewHolder(view)
            }
            else -> {
                val view = LayoutInflater.from(context).inflate(R.layout.list_item, parent, false)
                return CommonViewHolder(view)
            }
        }
    }

    override fun getItemCount(): Int = 15

    override fun getItemViewType(position: Int): Int {
        return when (position) {
            0 -> LOTTE_VIEW
            1 -> DABANG_VIEW
            2 -> LOTTE_POPUP_VIEW
            3 -> DABANG_VIEW
            12 -> YA_VIEW
            else -> AD_VIEW
        }
    }

    override fun onBindViewHolder(holder: RecyclerView.ViewHolder, position: Int) {
        when (holder) {
            is CommonViewHolder -> holder?.run {
                imageList[position % 10].let {
                    bindView(it)
                }
            }

            is LotteViewHolder -> holder?.run {
                bindView()
            }

            is DabangViewHolder -> holder?.run {
                bindView()
            }

            is YaViewHolder -> holder?.run { bindView() }
            is PopupViewHolder -> holder?.run { bindView() }
        }

    }


    inner class CommonViewHolder(val view: View) : RecyclerView.ViewHolder(view) {
        fun bindView(imageId: Int) {
            with(view) {
                Glide.with(context)
                        .load(imageId)
                        .diskCacheStrategy(DiskCacheStrategy.ALL)
                        .into(image_item)
            }

        }

    }

    inner class LotteViewHolder(val view: View) : RecyclerView.ViewHolder(view) {
        fun bindView() {
            var visiable = false
            with(view) {
                val animation = AlphaAnimation(0f, 1f)
                animation.duration = 2000

                lotte_button.setOnClickListener {
                    if (!visiable) {
                        visiable = true
                        lotte_button.isSelected = true
                        lotte_contents.animate().translationY(lotte_contents.height.toFloat())
                                .alpha(0.0f)
                                .setDuration(300)
                        lotte_contents.visibility = View.VISIBLE
                    } else {
                        visiable = false
                        lotte_button.isSelected = false
                        lotte_contents.visibility = View.GONE
                    }

                }
                lotte_cancle_btn.setOnClickListener {
                    visiable = false
                    lotte_button.isSelected = false
                    lotte_contents.visibility = View.GONE
                }
            }

        }
    }

    inner class DabangViewHolder(val view: View) : RecyclerView.ViewHolder(view) {
        fun bindView() {
            var visiable = false
            with(view) {
                dabang_button.setOnClickListener {
                    if (!visiable) {
                        visiable = true
                        dabang_button.isSelected = true
                        dabang_contents.visibility = View.VISIBLE
                    } else {
                        visiable = false
                        dabang_button.isSelected = false
                        dabang_contents.visibility = View.GONE
                    }
                }

                dabang_cancle_btn.setOnClickListener {
                    visiable = false
                    dabang_button.isSelected = false
                    dabang_contents.visibility = View.GONE
                }
            }
        }
    }
    inner class PopupViewHolder(var view: View) : RecyclerView.ViewHolder(view){
        fun bindView() {

        }
    }

    inner class YaViewHolder(var view: View) : RecyclerView.ViewHolder(view) {
        fun bindView() {
            with(view) {
                thumbnail_view.setOnClickListener {
                    val intent = Intent(context, DetailActivity::class.java)
                    intent.putExtra("detail", 0)
                    context.startActivity(intent)

                }
                video.setOnClickListener {
                    val intent = Intent(context, DetailActivity::class.java)
                    intent.putExtra("detail", 1)
                    context.startActivity(intent)
                }
            }
        }
    }
}

